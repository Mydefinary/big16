package service.dto;

import lombok.Data;

@Data
public class ResendCodeRequest {
    private String email;
}